package com.example.client;

public class Endpoints {

    String lat;
    String log;
    long id;

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Endpoints() {
    }

    public Endpoints(String lat, String log, long id) {
        this.lat = lat;
        this.log = log;
        this.id = id;
    }
}

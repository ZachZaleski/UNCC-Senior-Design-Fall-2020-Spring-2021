package com.example.client;

import androidx.annotation.LongDef;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.Provider;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity implements LocationListener {
    TextView receivedText;
    Button  network;
    public static String ip;
    public static int port;
    public static String messageToBeSent;
    public static String messageReceived;
    public Socket socket = null;
    public static final byte[] buffer = new byte[1024];
    public LocationManager locationManager;
    public Context context;
    public Client client;
    public String latitude;
    public String longitude;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        receivedText = findViewById(R.id.receivedText);
        network = findViewById(R.id.findNetwork);
        final Handler handler = new Handler();

        // We need to either create a new Thread OR use the below line
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitNetwork().build();
        StrictMode.setThreadPolicy(policy);

        setTitle("Client");

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10,
                (float) 0.5, this);


        context = this;
        network.setOnClickListener(new View.OnClickListener() {
            //            @RequiresApi(api = Build.VERSION_CODES.P)
            @Override
            public void onClick(View v) {

                    try {

                        network.setEnabled(false);

                        port = 8000;
                        ip = "192.168.0.167";
                        client = new Client();
                        client.execute();

                    } catch (Exception e) {
                        e.printStackTrace();
                        network.setEnabled(true);

                        Toast.makeText(MainActivity.this,"Try again !",Toast.LENGTH_SHORT).show();
                    }
                }

        });

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

        latitude = String.valueOf(location.getLatitude());
        longitude = String.valueOf(location.getLongitude());
    }


    class Client extends AsyncTask<Void,Void,Void>{

        Socket socket;

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                socket = new Socket(ip, port);
            } catch (IOException e) {
                e.printStackTrace();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Task failed in creating a socket", Toast.LENGTH_SHORT).show();
                    }
                });
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(MainActivity.this, "Please wait", Toast.LENGTH_SHORT).show();
            network.setEnabled(false);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Toast.makeText(MainActivity.this,"Socket created !",Toast.LENGTH_SHORT).show();

            ReceiveData receiveData = new ReceiveData();
            receiveData.execute();
        }

        public Socket socketGetter() {
            return this.socket;
        }
    }


    class SendData extends AsyncTask<Void, Void, Void> {
        Socket socket;

        @RequiresApi(api = Build.VERSION_CODES.P)
        @Override
        protected Void doInBackground(Void... voids) {

            socket = client.socketGetter();
            DataOutputStream dataOutputStream = null;
            messageToBeSent = null;
            try {
                dataOutputStream = new DataOutputStream(socket.getOutputStream());
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();

            }
            try {

                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return null;
                }

                    if(locationManager.isLocationEnabled()){

                     Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

                        if(location != null){
                            double randLat = location.getLatitude();
                            double randLongi = location.getLongitude();
                            messageToBeSent = "ID1" + "," + randLat +","+ randLongi;
                            dataOutputStream.writeUTF(messageToBeSent);
                            Log.d("TAG", "MSG SENT Actual: " + messageToBeSent);

                        } else {
                            Random rd = new Random();

                            float randLat = (float) (35.3072 + rd.nextFloat() * (0.007));
                            float randLongi = (float) (-80.7373 + rd.nextFloat() * (0.007));
                            messageToBeSent = "ID1" + "," + randLat +","+ randLongi;
                            dataOutputStream.writeUTF(messageToBeSent);
                            Log.d("TAG", "MSG SENT Random: " + messageToBeSent);

                        }

                    }
                    else {

                        Random rd = new Random();
                        double randLat =  (35.3072 + rd.nextDouble()*(0.007));
                         double randLongi =  (-80.7373 ) + rd.nextDouble() * (-0.007);
                        messageToBeSent = "ID1" + "," + randLat +","+ randLongi;
                        dataOutputStream.writeUTF(messageToBeSent);
                        Log.d("TAG", "MSG SENT Random: " + messageToBeSent);

                    }

            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();;
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            ReceiveData receiveData = new ReceiveData();
            receiveData.execute();
        }
    }





    class ReceiveData extends AsyncTask<Void,Void,Double>{

        Socket socket;

        @Override
        protected void onPostExecute(Double doubles) {
            super.onPostExecute(doubles);

            if(doubles != -1){

                receivedText.setText(doubles.toString());

                if(doubles > 9){
                    receivedText.setBackgroundColor(getResources().getColor(R.color.high));
                } else if (doubles <= 9 & doubles > 7){
                    receivedText.setBackgroundColor(getResources().getColor(R.color.medium));

                }else if (doubles <=7 ){
                    receivedText.setBackgroundColor(getResources().getColor(R.color.low));
                }

            }

            SendData sendData = new SendData();
            sendData.execute();

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Double doInBackground(Void... voids) {
            socket = client.socketGetter();
            double riskScore = -1;
            int bytes;
            DataInputStream dataInputStream = null ;
            try {
                dataInputStream = new DataInputStream(socket.getInputStream());
                bytes = dataInputStream.read(buffer);
                messageReceived = new String((byte[]) buffer, 0, bytes);
                String[] strings = messageReceived.split(",");
                riskScore = Double.parseDouble(strings[0]);
                Log.d("TAG", "MESSAGE RECEIVED : " + riskScore);

            } catch (IOException e) {
                e.printStackTrace();
            }

            return riskScore;
        }
    }


}
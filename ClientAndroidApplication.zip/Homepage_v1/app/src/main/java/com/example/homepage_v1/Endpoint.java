package com.example.homepage_v1;

import java.util.Random;

public class Endpoint {

    String latitude;
    String longitude;
    String id;


    public float getColor() {
        return color;
    }

    public void setColor(float color) {
        this.color = color;
    }

    float color;

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Endpoint() {
    }

    public Endpoint(String latitude, String longitude, String id) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.id = id;
    }

    @Override
    public String toString() {
        return "Endpoint{" +
                "latitude='" + latitude + '\'' +
                ", longitude='" + longitude + '\'' +
                ", id='" + id + '\'' +
                '}';
    }
}

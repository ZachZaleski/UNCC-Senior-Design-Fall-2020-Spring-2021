package com.example.homepage_v1;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.FragmentActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class MainActivity
        extends FragmentActivity implements OnMapReadyCallback {
    public static String ip;
    public static int port;
    public static String messageReceived;
    public Socket socket = null;
    public static final byte[] buffer = new byte[6820];
    public static GoogleMap map;

    Double startLati = 35.306758;
    Double startLongi = -80.743803;
    Double topLeftLati = 35.313044;
    Double topLeftLongi = startLongi;
    Double topRightLati = topLeftLati;
    Double topRightLongi = -80.737473;
    Double botRightLati = startLati;
    Double botRightLongi = topRightLongi;
    Double endLati = startLati;
    Double endLongi = startLongi;
    ArrayList<Endpoint> endpoints = new ArrayList<>();
    ArrayList<String> endpointsID = new ArrayList<>();

    LatLng Northcarolina = new LatLng(35.310443, -80.741206);
    HashMap<String,ArrayList<Object>> clients = new HashMap<String, ArrayList<Object>>();

    public static double RiskScore = 0;
    public static double heartRate = 0;
    public static String decision = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // We need to either create a new Thread OR use the below line
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitNetwork().build();
        StrictMode.setThreadPolicy(policy);
        setTitle("SafeWorkZone");
        findViewById(R.id.HR).setBackgroundResource(R.drawable.hr);
        findViewById(R.id.alertLevel).setBackgroundResource(R.drawable.alert);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }


    class Client extends AsyncTask<Void,Void,Socket>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(MainActivity.this, "Please Wait", Toast.LENGTH_SHORT).show();

        }

        @Override
        protected void onPostExecute(Socket values) {
            super.onPostExecute(values);
            Toast.makeText(MainActivity.this, "Created the socket", Toast.LENGTH_SHORT).show();
            socket = values;
            ReceiveData receiveData = new ReceiveData();
            receiveData.execute();
        }

        @Override
        protected Socket doInBackground(Void... voids) {
            port = 8000;
            ip = "192.168.0.167";

            try {
                socket = new Socket(ip, port);
            } catch (IOException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Something went wrong ", Toast.LENGTH_SHORT).show();
                    }
                });
                Client client = new Client();
                client.execute();
            }

            return socket;
        }


    }


    class SendData extends AsyncTask<Void,Void,Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();





        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            ReceiveData receiveData = new ReceiveData();
            receiveData.execute();
        }

        @Override
        protected Void doInBackground(Void... voids) {

                DataOutputStream dataOutputStream = null;
                try {
                    dataOutputStream = new DataOutputStream(socket.getOutputStream());
                    dataOutputStream.writeUTF("");
                } catch (IOException e) {
                    e.printStackTrace();
                    ReceiveData receiveData = new ReceiveData();
                    receiveData.execute();
            }
            return null;
        }
    }


    class ReceiveData extends AsyncTask<Void, Endpoint, ArrayList<Endpoint>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            findViewById(R.id.HR).setBackgroundResource(0);
            findViewById(R.id.alertLevel).setBackgroundResource(0);

        }

        @Override
        protected void onPostExecute( ArrayList<Endpoint> values) {
            super.onPostExecute(values);

            runOnUiThread(new Runnable() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, "Number of Active Workers in Work Zone " + values.size(), Toast.LENGTH_SHORT).show();

                    TextView textView = findViewById(R.id.alertLevel);
                    textView.setText(String.valueOf(RiskScore));

                    TextView textView1 = findViewById(R.id.Alerts);
                    findViewById(R.id.alertLevel).setBackgroundResource(R.drawable.alert);

                    if(RiskScore > 9){
//                        findViewById(R.id.alertLevel).setBackgroundColor(getResources().getColor(R.color.high));
                        textView.setTextColor(getResources().getColor(R.color.high));
                        findViewById(R.id.alertLevel).setBackgroundResource(R.drawable.alert);

                        if(!decision.equals("")){
//                            findViewById(R.id.Alerts).setBackgroundColor(getResources().getColor(R.color.high));
                            textView1.setTextColor(getResources().getColor(R.color.high));
                            textView1.setText(decision);
                        } else {
                            findViewById(R.id.Alerts).setBackgroundColor(getResources().getColor(R.color.white));
                            textView1.setText(decision);
                        }

                    } else if(RiskScore > 7 & RiskScore <= 9){
//                        findViewById(R.id.alertLevel).setBackgroundColor(getResources().getColor(R.color.medium));
                        textView.setTextColor(getResources().getColor(R.color.medium));
                        findViewById(R.id.alertLevel).setBackgroundResource(R.drawable.alert);

                        if(!decision.equals("")){
//                            findViewById(R.id.Alerts).setBackgroundColor(getResources().getColor(R.color.medium));
                            textView1.setTextColor(getResources().getColor(R.color.medium));
                            textView1.setText(decision);

                        }else {
                            findViewById(R.id.Alerts).setBackgroundColor(getResources().getColor(R.color.white));
                            textView1.setText(decision);
                        }

                    } else if(RiskScore > 0 & RiskScore <= 7){
//                        findViewById(R.id.alertLevel).setBackgroundColor(getResources().getColor(R.color.low));
                        textView.setTextColor(getResources().getColor(R.color.low));

//                            findViewById(R.id.Alerts).setBackgroundColor(getResources().getColor(R.color.white));
                        textView1.setTextColor(getResources().getColor(R.color.medium));

                        textView1.setText(decision);

                    }


                    findViewById(R.id.HR).setBackgroundResource(R.drawable.hr);

                    TextView textView2 = findViewById(R.id.HR);
                    textView2.setText(String.valueOf((int)heartRate));


//                    if(heartRate <= 0){
//
//                        findViewById(R.id.HR).setBackgroundColor(getResources().getColor(R.color.low));
//                        textView2.setText(String.valueOf(0));
//
//                    }
//
//                    else if(heartRate > 0 & heartRate < 50){
//                        findViewById(R.id.HR).setBackgroundColor(getResources().getColor(R.color.low));
//                        textView2.setText(String.valueOf(heartRate));
//
//
//                    } else if(heartRate >= 50 & heartRate < 90) {
//                        findViewById(R.id.HR).setBackgroundColor(getResources().getColor(R.color.medium));
//                        textView2.setText(String.valueOf(heartRate));
//
//
//                    } else if(heartRate >= 90) {
//                        findViewById(R.id.HR).setBackgroundColor(getResources().getColor(R.color.high));
//                        textView2.setText(String.valueOf(heartRate));
//
//                    }

                    ArrayList<String> activeTags = new ArrayList<>();

                    try{
                        if(values.size() > 0 & clients.size() > 0 ) {
                            for(Endpoint endpoint:values){
                                activeTags.add(endpoint.getId());
                                if(clients.get(endpoint.getId()).size() == 1 ){

                                    Marker marker =  map.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.defaultMarker((Float) clients.get(endpoint.getId()).get(0)))
                                            .position(new LatLng(Double.parseDouble(endpoint.getLatitude()),Double.parseDouble(endpoint.getLongitude())))
                                    );
                                    marker.setTag(endpoint.getId());
                                    ArrayList<Object> arrayList = clients.get(endpoint.getId());
                                    arrayList.add(marker);
                                    clients.put(endpoint.getId(),arrayList);
                                    marker.setPosition(new LatLng(Double.parseDouble(endpoint.getLatitude()),Double.parseDouble(endpoint.getLongitude())));

                                } else if(clients.get(endpoint.getId()).size() == 2){

                                    ArrayList<Object> arrayList = clients.get(endpoint.getId());
                                    Marker marker = (Marker) arrayList.get(1);
                                    marker.setPosition(new LatLng(Double.parseDouble(endpoint.getLatitude()),Double.parseDouble(endpoint.getLongitude())));
                                }

                            }

                        } else if(values.size() == 0 ){

                            map.clear();
                            map.moveCamera(CameraUpdateFactory.newLatLngZoom(Northcarolina, 16));
                            Polygon polygon1 = map.addPolygon(new PolygonOptions()
                                    .clickable(true)
                                    .add(
                                            new LatLng(startLati, startLongi),
                                            new LatLng(topLeftLati, topLeftLongi),
                                            new LatLng(topRightLati, topRightLongi),
                                            new LatLng(botRightLati, botRightLongi),
                                            new LatLng(endLati, endLongi))
                                    .strokeColor(Color.RED)
                                    .fillColor(Color.argb(50, 255, 0, 0)));
                        }

                        ArrayList<Marker> activeMarkers = new ArrayList<>();

                        for(String string : clients.keySet()){
                            if(clients.get(string).size() == 2){
                                activeMarkers.add((Marker) clients.get(string).get(1));
                            }
                        }

                        for(Marker marker : activeMarkers){
                            if(!activeTags.contains(marker.getTag())){
                                ArrayList<Object> newArray = clients.get(marker.getTag());
                                newArray.remove(1);
                                clients.put((String) marker.getTag(),newArray);
                                marker.remove();
                            }
                        }

                        SendData sendData = new SendData();
                        sendData.execute();

                    } catch (Exception e){

                        map.clear();
                        map.moveCamera(CameraUpdateFactory.newLatLngZoom(Northcarolina, 16));
                        Polygon polygon1 = map.addPolygon(new PolygonOptions()
                                .clickable(true)
                                .add(
                                        new LatLng(startLati, startLongi),
                                        new LatLng(topLeftLati, topLeftLongi),
                                        new LatLng(topRightLati, topRightLongi),
                                        new LatLng(botRightLati, botRightLongi),
                                        new LatLng(endLati, endLongi))
                                .strokeColor(Color.RED)
                                .fillColor(Color.argb(50, 255, 0, 0)));


                        SendData sendData = new SendData();
                        sendData.execute();

                    }


                }

            });}


        @Override
        protected ArrayList<Endpoint> doInBackground(Void... values) {

            int bytes;
            DataInputStream dataInputStream ;
            Random random = new Random();

            endpointsID.clear();
            endpoints.clear();

                 try {
                     dataInputStream =  new DataInputStream(socket.getInputStream());
                     bytes = dataInputStream.read(buffer);
                     messageReceived = new String((byte[]) buffer, 0, bytes);
                     String[] strings = messageReceived.split(",");

                     RiskScore = Double.parseDouble(strings[0]);
                     if(RiskScore > 7){
                         decision = strings[1];
                     } else {
                         decision = "";
                     }

                     for (int i = 0; i < strings.length; i++){

                         if(strings[i].contains("ID") & !endpointsID.contains(strings[i])){
                             heartRate = Double.parseDouble(strings[i+3]);
                             if(heartRate < 0){
                                 heartRate = 0;
                             }

                             if(!clients.keySet().contains(strings[i])){
                                 Log.d("TAG", "doInBackground: "+"here2");
                                 Endpoint endpoint = new Endpoint(strings[i+1],strings[i+2],strings[i]);
                                 float color = random.nextFloat()*250;
                                 ArrayList<Object> arrayList = new ArrayList<>();
                                 arrayList.add(color);
                                 clients.put(strings[i],arrayList);
                                 endpoints.add(endpoint);
                                 endpointsID.add(strings[i]);
                                 Log.d("TAG", "doInBackground: "+endpoint.toString());
                             } else {
                                 Log.d("TAG", "doInBackground: "+"here3");
                                 Endpoint endpoint = new Endpoint(strings[i+1],strings[i+2],strings[i]);
                                 endpoints.add(endpoint);
                                 endpointsID.add(strings[i]);

                                 Log.d("TAG", "doInBackground: "+endpoint.toString());
                             }

                         }
                     }
                     return endpoints;


                 }
                 catch (IOException e) {
                     e.printStackTrace();
                     SendData sendData = new SendData();
                     sendData.execute();
                 }

            return null;

        }


        }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;

        map.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                Log.d("TAG", "onMapClick: " + latLng.toString());

                   Client client = new Client();
                   client.execute();

            }});

                map.moveCamera(CameraUpdateFactory.newLatLngZoom(Northcarolina, 16));
                Polygon polygon1 = map.addPolygon(new PolygonOptions()
                        .clickable(true)
                        .add(
                                new LatLng(startLati, startLongi),
                                new LatLng(topLeftLati, topLeftLongi),
                                new LatLng(topRightLati, topRightLongi),
                                new LatLng(botRightLati, botRightLongi),
                                new LatLng(endLati, endLongi))
                        .strokeColor(Color.RED)
                        .fillColor(Color.argb(50, 255, 0, 0)));



            };


    }










































//
//                    if (!(((longitude > startLongi) && (longitude < botRightLongi)) && ((latitude > startLati) && (latitude < topLeftLati)))) {
//                        runOnUiThread(new Runnable() {
//                            public void run() {
//                                Toast.makeText(MainActivity.this, "ERROR: MARKER 1 YOU'RE OUTSIDE OF THE BOUNDS!!!!!!", Toast.LENGTH_SHORT).show();
//                            }
//                        });
//                    }
//                    if (!(((longitude2 > startLongi) && (longitude2 < botRightLongi)) && ((latitude2 > startLati) && (latitude2 < topLeftLati)))) {
//                        runOnUiThread(new Runnable() {
//                            public void run() {
//                                Toast.makeText(MainActivity.this, "ERROR: MARKER 2 YOU'RE OUTSIDE OF THE BOUNDS!!!!!!", Toast.LENGTH_SHORT).show();
//                            }
//                        });
//                    }
//                    if (!(((longitude3 > startLongi) && (longitude3 < botRightLongi)) && ((latitude3 > startLati) && (latitude3 < topLeftLati)))) {
//                        runOnUiThread(new Runnable() {
//                            public void run() {
//                                Toast.makeText(MainActivity.this, "ERROR: MARKER 3 YOU'RE OUTSIDE OF THE BOUNDS!!!!!!", Toast.LENGTH_SHORT).show();
//                            }
//                        });
//                    }
//                    if (!(((longitude4 > startLongi) && (longitude4 < botRightLongi)) && ((latitude4 > startLati) && (latitude4 < topLeftLati)))) {
//                        runOnUiThread(new Runnable() {
//                            public void run() {
//                                Toast.makeText(MainActivity.this, "ERROR: MARKER 4 YOU'RE OUTSIDE OF THE BOUNDS!!!!!!", Toast.LENGTH_SHORT).show();
//                            }
//                        });
//                    }
